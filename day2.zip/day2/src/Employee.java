public class Employee extends Person implements Printable{
    private int salary;

    public Employee(String name, int age, int salary) {
        super(name, age);
        this.salary = salary;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Employee" +super.toString() +"salary=" + salary +
                '}';
    }

    @Override
    public void printDetails() {
      System.out.println(super.toString() + "salary=" + salary);
    }
}
