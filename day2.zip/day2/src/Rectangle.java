public class Rectangle extends Shape{
    private double height;
    private double width ;

    public Rectangle(double height , double width) {
        this.height = height;
        this.width = width ;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    @Override
    double area() {
        return height*width ;
    }
}
