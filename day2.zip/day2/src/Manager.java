public class Manager extends Employee implements Printable{

    private String department ;

    public Manager(String name, int age, int salary, String department) {
        super(name, age, salary);
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "Manager{" + super.toString() +
                "department='" + department + '\'' +
                '}';
    }
}
