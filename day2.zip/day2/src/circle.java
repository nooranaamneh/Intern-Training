public class circle extends  Shape{
    private double r ;

    public circle(double r) {
        this.r = r;
    }

    @Override
    double area() {
        return Math.pow(r,2) * Math.PI;
    }

    public void setR(double r) {
        this.r = r;
    }

}
