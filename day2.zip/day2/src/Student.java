public class Student extends Person implements Printable{
    private String id ;

    @Override
    public void printDetails() {
       System.out.println(super.toString() + "id=" + id);
    }

    public Student(String name, int age, String id) {
        super(name, age);
        this.id = id;
    }
}
