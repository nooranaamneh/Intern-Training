import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        Shape rectangle = new Rectangle(6.2 , 6.2);
        Shape circle = new circle(6.2);
        Shape triangle = new Triangle(6.2 , 6.2);

        List <Shape> list = new ArrayList<>();
        list.add(rectangle);
        list.add(circle);
        list.add(triangle);

        for(int i =0;i<list.size();i++){
            String w = "";
            Shape s = list.get(i);
            if(s instanceof circle){
                w = "circle ";
            }else if(s instanceof  Rectangle){
                w = "Rectangle ";
            }else{
                w = "Triangle ";
            }
            System.out.print(w);
        printArea( list.get(i));
        }


        ////////////////////////////////////////////////////////////////////////////////////

        Person person1 = new Student("maysan" , 21, "1231420");
        Person person2 = new Employee("maysan" , 21, 500);

        if(person1 instanceof Student){
            Student student = (Student) person1 ;
        }
        else {
            System.out.println("not student");
        }
        if(person2 instanceof Employee){
           Employee employee = (Employee) person2 ;
        }
        else {
            System.out.println("not student");
        }
    }

    public static void printArea(Shape shape) {
        System.out.println("Area = " + shape.area());
    }

}