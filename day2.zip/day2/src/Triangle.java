public class Triangle extends Shape{

    private double height ;
    private double base;

    public Triangle(double height , double base) {
        this.height = height;
        this.base = base;
    }

    @Override
    double area() {
        return 0.5*height*base;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public void setBase(double base) {
        this.base = base;
    }
}
